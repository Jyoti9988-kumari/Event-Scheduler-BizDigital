students = []

def add_student():
    name = input("Enter student name: ")
    roll = input("Enter student roll number: ")
    age = input("Enter student age: ")
    students.append({"name": name, "roll": roll, "age": age})
    print("Student added successfully!\n")

def view_students():
    if not students:
        print("No students found.\n")
    else:
        for student in students:
            print(f"Name: {student['name']}, Roll: {student['roll']}, Age: {student['age']}")
        print()

def search_student():
    roll = input("Enter roll number to search: ")
    found = False
    for student in students:
        if student['roll'] == roll:
            print(f"Name: {student['name']}, Roll: {student['roll']}, Age: {student['age']}\n")
            found = True
    if not found:
        print("Student not found!\n")

def update_student():
    roll = input("Enter roll number to update: ")
    for student in students:
        if student['roll'] == roll:
            student['name'] = input("Enter new name: ")
            student['age'] = input("Enter new age: ")
            print("Student updated successfully!\n")
            return
    print("Student not found!\n")

def delete_student():
    roll = input("Enter roll number to delete: ")
    for student in students:
        if student['roll'] == roll:
            students.remove(student)
            print("Student deleted successfully!\n")
            return
    print("Student not found!\n")

def menu():
    while True:
        print("----- Student Management System -----")
        print("1. Add Student")
        print("2. View Students")
        print("3. Search Student")
        print("4. Update Student")
        print("5. Delete Student")
        print("6. Exit")

        choice = input("Enter your choice (1-6): ")

        if choice == '1':
            add_student()
        elif choice == '2':
            view_students()
        elif choice == '3':
            search_student()
        elif choice == '4':
            update_student()
        elif choice == '5':
            delete_student()
        elif choice == '6':
            print("Exiting Program... Goodbye!")
            break
        else:
            print("Invalid choice! Please enter a number between 1 and 6.\n")

menu()
